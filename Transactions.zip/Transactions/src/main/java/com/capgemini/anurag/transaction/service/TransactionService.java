package com.capgemini.anurag.transaction.service;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.anurag.transaction.dao.AccountDAO;
import com.capgemini.anurag.transaction.dao.ChequeDAO;
import com.capgemini.anurag.transaction.dao.TransactionDAO;
import com.capgemini.anurag.transaction.dto.Account;
import com.capgemini.anurag.transaction.dto.Cheque;
import com.capgemini.anurag.transaction.dto.Transaction;

@Service
public class TransactionService {
    @Autowired
    TransactionDAO tdao;
    @Autowired
	ChequeDAO cdao;
    @Autowired
    AccountDAO adao;
    public void setTdao(TransactionDAO tdao) { this.tdao=tdao;} 
    public void setCdao(ChequeDAO cdao){this.cdao=cdao;}
    public void setAdao(AccountDAO adao) {this.adao = adao;}
	@Transactional
    public boolean creditUsingSlip(long account_id,double amount)
    {
    	Account acc= adao.findById(account_id).get();
    	acc.setBalance(acc.getBalance()+amount);
    	Transaction t = new Transaction();
    	t.setAmount(amount);
    	t.setCheque(null);
    	t.setType("Credit");
    	t.setAccId(account_id);
    	LocalDate localDate = LocalDate.now();
    	Date date = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    	t.setDateOfTrans(date);
    	if(tdao.save(t)!=null)
    		return true;
    	else 
    		return false;
    }
	@Transactional
    public boolean creditUsingCheque(long account_id,Cheque cheque)
    {
    	Transaction t = new Transaction();
    	Account acc= adao.findById(account_id).get();
    	acc.setBalance(acc.getBalance()+cheque.getAmount());
    	cdao.save(cheque);
    	cdao.flush();
    	//t.setCheque(cheque);
    	t.setAmount(cheque.getAmount());
    	t.setType("Credit");
    	t.setAccId(account_id);
    	LocalDate localDate = LocalDate.now();
    	Date date = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    	t.setDateOfTrans(date);
    	t.setCheque(cheque);
    	if(tdao.save(t)!=null)
    		return true;
    	else
    		return false;
    }
}
