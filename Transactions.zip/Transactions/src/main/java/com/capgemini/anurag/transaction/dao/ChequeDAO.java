package com.capgemini.anurag.transaction.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capgemini.anurag.transaction.dto.Cheque;
@Repository
public interface ChequeDAO extends JpaRepository<Cheque,String>
{

}
